const express = require('express');
const path = require('path');
const { testController, emailController } = require('./controllers/api/apiControllers')

const app = express();
const port = process.env.PORT || 5000;

//configuring static path for frontend resources
app.use(express.static(path.join(__dirname, 'client/build')));
app.use(express.json());
app.use(express.urlencoded());

app.post("/api/email", (req,res) => emailController(req,res));

//route to get language pack templates
app.get("/api/test", (req,res) => testController(req,res));

//route for rendering frontend build package
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname+'/client/build/index.html'));
  });

//setting up a listener
app.listen(port, () => {
    console.log(`Server started on port ${port}`)
})