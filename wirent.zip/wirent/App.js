import { useEffect, useState } from 'react';
import About from './components/About';
import CookieModal from './components/CookieModal';
import Email from './components/Email';
import Footer from './components/Footer';
import Header from './components/Header';
import Hero from './components/Hero';
import Loader from './components/Loader';
import MenuModal from './components/MenuModal';
import Technology from './components/Technology';

function App() {

  const [message, setMessage] = useState({});
  const [lang, setLang] = useState("en");
  const [isLoading, setIsLoading] = useState(true);
  const [cookieModal, setCookieModal] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const langSwitch = () => {
    if(lang==="en"){
      setLang("pl");
      window.localStorage.setItem('lang','pl');
    }
    else{
      setLang("en");
      window.localStorage.setItem('lang','en');
    }
  }

  useEffect(() => {
    setIsLoading(true);
      if(window.localStorage.getItem('accept')&&window.localStorage.getItem('lang')){
        setLang(window.localStorage.getItem('lang'));
      }
      else{
        setCookieModal(true);
        window.localStorage.setItem('lang',lang);
      }
    fetch('/api/test').then(res=>res.json()).then(msg => {setMessage(msg); setTimeout(()=>setIsLoading(false),1000)});
  }, [])
  return (
    <div className="bg-circuit-board w-screen">
      {isLoading?<Loader />:null}
      {cookieModal?<CookieModal text={message[lang]?.cookieModal} action={()=>{setCookieModal(false); window.localStorage.setItem('accept','true')}}/>:null}
      <Header text={message[lang]?.header} langChange={langSwitch} openModal={()=>{setMenuOpen(true)}}/>
      <Hero text={message[lang]?.hero}/>
      <About text={message[lang]?.about}/>
      <Technology text={message[lang]?.technology}/>
      <Email text={message[lang]?.email} language={lang}/>
      <Footer text={message[lang]?.header}/>
      <MenuModal text={message[lang]?.header} action={()=>{setMenuOpen(false)}} opened={menuOpen}/>
    </div>
  );
}

export default App;
