const { templates } = require("../../templates")
const fs = require('fs');

const testController = (req,res) => {
    res.json(templates)
}

const emailController = (req,res) => {
    let flag = 0;
    let emails = undefined;
    fs.readFile('emails.json', (err,data)=>{
        if(!err){
            emails = JSON.parse(data).table;
            emails.map((obj)=>{
                if(obj.email===req.body.email){
                    flag = 1;
                }
            })
        }
        if(flag===0){
            emails.push({"email": req.body.email});
            fs.writeFile('emails.json', JSON.stringify({"table":emails}), (err)=>{
                if(!err){
                    res.json({
                        status: "ok",
                        text: {
                            en: "Added email to subscription database!",
                            pl: "Dodano email do bazy subskrybentów!"
                        }
                    })
                }
            });
        }
        else{
            res.json({
                status: "err",
                text: {
                    en: "Already a subscriber!",
                    pl: "Email już subskrybuje!"
                }
            })
        }
    })
}

exports.testController = testController
exports.emailController = emailController