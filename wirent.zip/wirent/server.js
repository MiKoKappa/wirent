const express = require('express');
const path = require('path');
// const cors = require('cors');
const { testController, emailController } = require('./controllers/api/apiControllers')

const app = express();
const port = process.env.PORT || 5000;

//configuring static path for frontend resources
app.use(express.static(path.join(__dirname, 'client/build')));
app.use(express.json());
app.use(express.urlencoded());
//cors configuration
// const corsOptions = {
//     origin: 'https://weathr-app.herokuapp.com',
//     optionsSuccessStatus: 200
//   }

app.post("/api/email", (req,res) => emailController(req,res));

//route to get current weather info
app.get("/api/test", (req,res) => testController(req,res));

//route for rendering frontend build package
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname+'/client/build/index.html'));
  });

//setting up a listener
app.listen(port, () => {
    console.log(`Server started on port ${port}`)
})