const templates = {
    en:{
        header:{
            home:"home",
            about:"about",
            technology:"technology",
            lang:"eng"
        },
        cookieModal:{
            title: "This site uses cookies!",
            sub: "Our site uses cookies in order to save information about your language preferences. Please agree to us using them to make your experience better. ",
            subtext: "Your yummy cookies are 100% safe with us!",
            button: "i constent"
        },
        hero:{
            title:"Bring smart technology to your own house!",
            sub:"wirent makes it simple to implement your own IoT solutions to make your home do whatever you want from wherever you are!",
            button:"find out how"
        },
        about:{
            question: "How does wirent work?",
            sub: "wirent is based on open source, easy to set up and manage software and hardware which makes getting into IoT much easier. See steps on the side to find out how to do it yourself!",
            tabs:{
                1:{
                    title:"Get all of the required hardware",
                    sub:"You will need a Raspberry Pi or similar computer in order to set up a server and a sensor unit based on ESP8266 or EPS32."
                },
                2:{
                    title:"Set up your broker service",
                    sub:"With help of Mosquitto set up your very own MQTT protocol broker and make it all secure and protected. You can use docker for even easier process."
                },
                3:{
                    title:"Flash your smart device with code",
                    sub:"Flash ESP8266 or ESP32 with code containing broker info via Arduino IDE and plug everything together to form a smart sensor which will be connected to the service."
                },
                4:{
                    title:"Set everything up on dashboard",
                    sub:"Everything is working fine? Then push all your data to browser with dashboard. Just supply broker info and topics and you are done!"
                }
            }
        },
        technology:{
            title: "Technologies that we use",
            mosquitto: "Open source MQTT broker used to store and distribute messages among many topics. Fast, easy to configure and extremally reliable.",
            raspberry: "The heart of the project. A quad core microcomputer hosting the broker, working hard 24/7 to deliver best quality of service.",
            esp: "Mainly ESP8266 and ESP32 - great little electonic pieces cappable of sending sensor information via TCP protocols.",
            button: "learn more"
        },
        email:{
            title: "Find out about updates first!",
            button: "subscribe"
        }
    },
    pl:{
        header:{
            home:"home",
            about:"o nas",
            technology:"technologie",
            lang:"pol"
        },
        cookieModal:{
            title: "Ta strona używa ciasteczek!",
            sub: "Nasza strona używa ciasteczek aby zachować informacje o Twoich preferencjach językowych. Prosimy o wyrażenie zgody aby umilić Twoje doświadczenie. ",
            subtext: "Twoje ciasteczka są z nami w 100% bezpieczne!",
            button: "wyrażam zgodę"
        },
        hero:{
            title:"Inteligentna technologia w Twoim domu!",
            sub:"wirent czyni wdrożenie własnego systemu IoT banalnie prostym, abyś rozkazywał domu robić cokolwiek zechcesz, gdziekolwiek jesteś!",
            button:"dowiedź się jak"
        },
        about:{
            question: "Jak działa wirent?",
            sub: "wirent bazuje na otwartym, prostym w konfiguracji i zarządzaniu software oraz hardware pozwalając na wejście w świat IoT o wiele prościej. Zobacz wszystkie potrzebne kroki i dowiedz się jak zrobić to samemu!",
            tabs:{
                1:{
                    title:"Zdobądź potrzebny sprzęt",
                    sub:"Będziesz potrzebować Raspberry Pi lub podobnego komputera w celu uruchomienia serwera oraz urządzenie sensora bazujące na ESP8266 lub ESP32."
                },
                2:{
                    title:"Uruchom swojego brokera",
                    sub:"Z pomocą Mosquitto uruchom własnego brokera MQTT i odpowiednio go zabezpiecz. Możesz użyć dockera aby jeszcze bardziej uprościć proces."
                },
                3:{
                    title:"Wgraj odpowiedni kod do inteligentnego urządzenia",
                    sub:"Wgraj kod do ESP8266 lub EPS32 zawierający informacje o brokerze za pomocą Arduino IDE i zepnij wszystko razem aby utworzyć inteligentny sensor, możliwy do podłączenia z serwisem."
                },
                4:{
                    title:"Ustaw odpowiednio panel sterowania",
                    sub:"Wszystko działa odpowiednio? Przenieś wszystkie informacje do przeglądarki za pomocą panelu. Podaj tylko informacje o brokerze i tematach i wszystko gotowe!"
                }
            }
        },
        technology:{
            title: "Technologie, których używamy",
            mosquitto: "Broker MQTT o otwartym kodzie używany do przechowywania oraz dystrybucji wiadomości wśród wielu tematów. Szybki, łatwy w konfiguracji oraz ekstremalnie niezawodny.",
            raspberry: "Serce projektu. Mikrokomputer o procesorze quad-core urzymujący brokera, działający 24/7 aby dostarczyć najwyższy standard usługi.",
            esp: "Głównie ESP8266 oraz ESP32 - świetna mała elektronika będąca w stanie wysyłać informacje z sensoró za pomocą prokotołów TCP.",
            button: "dowiedź się więcej"
        },
        email:{
            title: "Dowiedź się o zmianach jako pierwszy!",
            button: "subskrybuj"
        }
    }
}

exports.templates = templates;